import "../../styles/Characters/Characters.css";
export declare const Characters: () => import("react/jsx-runtime").JSX.Element;
