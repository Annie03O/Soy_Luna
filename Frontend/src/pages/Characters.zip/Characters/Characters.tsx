import { CharacterPage } from "../../components/CharacterPage"
import { Page } from "../../models/classes/AllType"  
import { characters1, characters2 } from "../../models/objects/CharacterItem"
import "../../styles/Characters/Characters.css"
import { Link } from "react-router-dom"


export const Characters = () => {
    return <>   
    <main className="characterPage">  
    <h1 className="charh1">Meet the Characters</h1>
        <section className="character-wrapper">
        <section className="firstrow">
            {characters1.map((c) => (
                <Link to={c.path}>
                    <CharacterPage key={c.id} label={c.label} imgUrl={c.imgUrl} id={c.id} actor={c.actor} path={c.path}/>
                </Link>
            ))}
        </section>
        <section className="secondrow">
            {characters2.map((c) => (
                <Link to={c.path}>
                    <CharacterPage key={c.id} label={c.label} imgUrl={c.imgUrl} id={c.id} actor={c.actor} path={c.path}/>
                </Link>
            ))}
        </section>
    </section>
    </main>
    </>
} 