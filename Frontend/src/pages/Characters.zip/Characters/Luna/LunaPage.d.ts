import "/src/styles/Characters/CharacterPage.css";
export declare const LunaPage: () => import("react/jsx-runtime").JSX.Element;
