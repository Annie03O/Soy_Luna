import "/src/styles/Characters/CharacterPage.css";
export declare const MatteoPage: () => import("react/jsx-runtime").JSX.Element;
