import "/src/styles/Characters/CharacterPage.css";
export declare const NinaPage: () => import("react/jsx-runtime").JSX.Element;
