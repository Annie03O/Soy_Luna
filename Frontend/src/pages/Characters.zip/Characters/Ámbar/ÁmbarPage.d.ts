import "/src/styles/Characters/CharacterPage.css";
export declare const ÁmbarPage: () => import("react/jsx-runtime").JSX.Element;
